import os
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# Constants
USERS_FILE = 'users.txt'
GRADES_FILE = 'grades.txt'
ECA_FILE = 'eca.txt'
PASSWORDS_FILE = 'passwords.txt'
SUBJECTS = ['FOM', 'IT', 'FODS', 'English']
COLLEGE = "🎓 The British College"
DEFAULT_COURSE = "📘 BSc (Hons) Computing"

def initialize_files():
    for filename in [USERS_FILE, GRADES_FILE, ECA_FILE, PASSWORDS_FILE]:
        if not os.path.exists(filename):
            with open(filename, 'w', encoding='utf-8') as f:
                pass

class User:
    def __init__(self, user_id):
        self.user_id = user_id

    def view_profile(self):
        with open(USERS_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                data = line.strip().split(',')
                if data[0] == self.user_id:
                    print(f"\n👤 ID: {data[0]}\n📛 Name: {data[1]}\n🎓 Role: {data[2]}\n📘 Course: {data[3]}")
                    break

class Student(User):
    def update_profile(self):
        name = input("Enter new name: ")
        lines = []
        with open(USERS_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                data = line.strip().split(',')
                if data[0] == self.user_id:
                    data[1] = name
                lines.append(','.join(data) + '\n')
        with open(USERS_FILE, 'w', encoding='utf-8') as f:
            f.writelines(lines)
        print("✅ Profile updated!")

    def view_grades(self):
        print("\n📊 Your Grades:")
        with open(GRADES_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                data = line.strip().split(',')
                if data[0] == self.user_id:
                    for i, mark in enumerate(data[1:]):
                        print(f"  {SUBJECTS[i]}: {mark}")
                    return

    def view_eca(self):
        print("\n🎯 ECA Activities:")
        with open(ECA_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                data = line.strip().split(',')
                if data[0] == self.user_id:
                    print("  " + ', '.join(data[1:]))
                    return

    def dashboard(self):
        print("\n📊 Personal Dashboard:")

        # Load grades
        with open(GRADES_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                data = line.strip().split(',')
                if data[0] == self.user_id:
                    grades = list(map(float, data[1:]))
                    break
            else:
                print("❌ No grades found.")
                return

        # Line chart of grades
        plt.plot(SUBJECTS, grades, marker='o', color='blue')
        plt.title("📈 Your Grade Trend")
        plt.ylabel("Marks")
        plt.grid(True)
        plt.tight_layout()
        plt.show()

        # Average grade and alert
        avg = sum(grades) / len(grades)
        print(f"\n📘 Your average grade: {avg:.2f}")
        if avg < 40:
            print("⚠️ Alert: Your performance is below threshold!")

        # Pie chart for subject-wise marks
        plt.pie(grades, labels=SUBJECTS, autopct='%1.1f%%', startangle=90)
        plt.title("🥧 Grade Distribution")
        plt.tight_layout()
        plt.show()

class Admin(User):
    def add_user(self):
        user_id = input("New ID: ")
        name = input("Name: ")
        role = 'student'
        course = input("Course Name (or press Enter for default): ")
        if not course:
            course = DEFAULT_COURSE
        password = input("Password: ")

        with open(PASSWORDS_FILE, 'r', encoding='utf-8') as f:
            if any(user_id in line for line in f):
                print("❌ ID already exists.")
                return

        with open(USERS_FILE, 'a', encoding='utf-8') as f:
            f.write(f"{user_id},{name},{role},{course}\n")
        with open(PASSWORDS_FILE, 'a', encoding='utf-8') as f:
            f.write(f"{user_id},{password}\n")
        with open(GRADES_FILE, 'a', encoding='utf-8') as f:
            grades = input("Enter grades (FOM IT FODS English): ").split()
            f.write(f"{user_id}," + ','.join(grades) + '\n')
        with open(ECA_FILE, 'a', encoding='utf-8') as f:
            eca = input("Enter ECAs (comma separated): ")
            f.write(f"{user_id}," + eca + '\n')
        print("✅ Student added!")

    def modify_user(self):
        user_id = input("Enter ID to modify: ")
        name = input("New name: ")
        new_grades = input("New grades (FOM IT FODS English): ").split()
        new_eca = input("New ECAs (comma separated): ")

        def update_file(file, user_id, new_data):
            updated_lines = []
            with open(file, 'r', encoding='utf-8') as f:
                for line in f:
                    data = line.strip().split(',')
                    if data[0] == user_id:
                        updated_lines.append(user_id + ',' + new_data + '\n')
                    else:
                        updated_lines.append(line)
            with open(file, 'w', encoding='utf-8') as f:
                f.writelines(updated_lines)

        update_file(USERS_FILE, user_id, f"{name},student,{DEFAULT_COURSE}")
        update_file(GRADES_FILE, user_id, ','.join(new_grades))
        update_file(ECA_FILE, user_id, new_eca)
        print("✅ User modified!")

    def delete_user(self):
        user_id = input("Enter ID to delete: ")
        for file in [USERS_FILE, GRADES_FILE, ECA_FILE, PASSWORDS_FILE]:
            with open(file, 'r', encoding='utf-8') as f:
                lines = [line for line in f if not line.startswith(user_id + ',')]
            with open(file, 'w', encoding='utf-8') as f:
                f.writelines(lines)
        print("🗑️ User deleted!")

    def generate_insights(self):
        print("\n📈 Insights:")
        df = pd.read_csv(GRADES_FILE, header=None, encoding='utf-8')
        df.columns = ['ID'] + SUBJECTS
        for subject in SUBJECTS:
            print(f"📚 Avg in {subject}: {df[subject].astype(float).mean():.2f}")

        eca_counts = {}
        with open(ECA_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                parts = line.strip().split(',')
                eca_counts[parts[0]] = len(parts[1:])
        most_active = max(eca_counts, key=eca_counts.get, default="None")
        print(f"🏆 Most active in ECA: {most_active} with {eca_counts.get(most_active,0)} activities")

    def dashboard(self):
        print("\n📊 Performance Analytics Dashboard:")
        df = pd.read_csv(GRADES_FILE, header=None, encoding='utf-8')
        df.columns = ['ID'] + SUBJECTS
        df.set_index('ID', inplace=True)

        avg_per_subject = df[SUBJECTS].astype(float).mean()
        avg_per_subject.plot(kind='bar', color='skyblue')
        plt.title("📊 Average Grade per Subject")
        plt.ylabel("Average Marks")
        plt.xlabel("Subjects")
        plt.grid(True)
        plt.tight_layout()
        plt.show()

        df[SUBJECTS].T.plot(marker='o')
        plt.title("📈 Grade Trends per Student")
        plt.ylabel("Marks")
        plt.xlabel("Subjects")
        plt.grid(True)
        plt.tight_layout()
        plt.show()

        eca_counts = {line.split(',')[0]: len(line.strip().split(',')) - 1 for line in open(ECA_FILE, 'r', encoding='utf-8')}
        df['ECA_Count'] = df.index.map(eca_counts).fillna(0).astype(int)
        plt.scatter(df['ECA_Count'], df[SUBJECTS].mean(axis=1), c='green')
        plt.title("🎯 ECA Involvement vs. Average Grade")
        plt.xlabel("ECA Count")
        plt.ylabel("Avg Grade")
        plt.grid(True)
        plt.tight_layout()
        plt.show()

        avg_grades = df[SUBJECTS].mean(axis=1)
        bins = [0, 40, 60, 80, 100]
        labels = ['<40', '40-60', '60-80', '>80']
        grade_groups = pd.cut(avg_grades, bins=bins, labels=labels, right=False)
        pie_data = grade_groups.value_counts().sort_index()
        pie_data.plot(kind='pie', autopct='%1.1f%%', startangle=90, colors=['red', 'orange', 'yellowgreen', 'green'])
        plt.title("🥧 Grade Distribution")
        plt.ylabel('')
        plt.tight_layout()
        plt.show()

        print("\n⚠️ Alerts (students below 40):")
        for sid, row in df.iterrows():
            if row[SUBJECTS].mean() < 40:
                print(f"❗ {sid}: Avg = {row[SUBJECTS].mean():.2f}")

def login():
    while True:
        uid = input("\n🆔 Enter ID: ")
        pwd = input("🔑 Enter Password: ")
        with open(PASSWORDS_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                user, password = line.strip().split(',')
                if user == uid and pwd == password:
                    with open(USERS_FILE, 'r', encoding='utf-8') as uf:
                        for u in uf:
                            if u.startswith(uid):
                                role = u.strip().split(',')[2]
                                print(f"\n✅ Login successful as {role.upper()}")
                                return uid, role
        print("❌ Invalid credentials. Try again.")

def main():
    initialize_files()

    if os.stat(PASSWORDS_FILE).st_size == 0:
        print("\n👤 No users found. Let's create the first admin.")
        uid = input("Enter Admin ID: ")
        name = input("Admin Name: ")
        pwd = input("Password: ")
        with open(PASSWORDS_FILE, 'a', encoding='utf-8') as f:
            f.write(f"{uid},{pwd}\n")
        with open(USERS_FILE, 'a', encoding='utf-8') as f:
            f.write(f"{uid},{name},admin,{DEFAULT_COURSE}\n")
        print("✅ Admin account created! Please log in.\n")

    print(f"\n🌟 Welcome to {COLLEGE} - {DEFAULT_COURSE} 🌟")
    uid, role = login()

    if role == 'admin':
        admin = Admin(uid)
        while True:
            print("\n🔧 Admin Menu:\n1. Add User\n2. Modify User\n3. Delete User\n4. Insights\n5. Dashboard\n6. Logout")
            c = input("Choose: ")
            if c == '1': admin.add_user()
            elif c == '2': admin.modify_user()
            elif c == '3': admin.delete_user()
            elif c == '4': admin.generate_insights()
            elif c == '5': admin.dashboard()
            elif c == '6': break
    else:
        student = Student(uid)
        while True:
            print("\n🎒 Student Menu:\n1. View Profile\n2. Update Profile\n3. View Grades\n4. View ECAs\n5. Dashboard\n6. Logout")
            c = input("Choose: ")
            if c == '1': student.view_profile()
            elif c == '2': student.update_profile()
            elif c == '3': student.view_grades()
            elif c == '4': student.view_eca()
            elif c == '5': student.dashboard()
            elif c == '6': break

if __name__ == "__main__":
    main()
